create function update_data_agg() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE contracts  SET is_closed = true where now() >= closing_date and is_closed = false;
    RETURN NULL;
END
$$;

alter function update_data_agg() owner to s285896;

